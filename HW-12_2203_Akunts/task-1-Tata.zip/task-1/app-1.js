let x = 6;
let y;
while (x != y) {
  y = prompt("Enter a number, please!");
  if (y < x) {
    alert("The num is small");
  } else if (y > x) {
    alert("The num is big");
    prompt("Enter a number, please!");
  } else {
    alert("Congratulations!");
    break;
  }
}
